package com.day4;

public class A {
	
	int b = 20;
	static int c = 30;
	int display() {
		return 10;
	}
	static void display1() {
		System.out.println(10);
	}

}
