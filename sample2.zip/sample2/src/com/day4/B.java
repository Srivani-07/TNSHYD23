package com.day4;

public class B {
	 
	 public static void main(String[] args) {
		
		A a1 = new A();
		
		System.out.println(a1.b);
		System.out.println(A.c);
		a1.display();
		A.display1();
	}

}
