package com.day3;

public class A {
	
         int b = 20;
         static int c= 30;
         int display() {
        	 return 10;
         }
         static void  display1() {
        	 System.out.println(10);
         }
	public static void main(String[] args) {
		int a = 10;
		A a1 = new A();
		System.out.println(a);
		System.out.println(a1.b);
		System.out.println(A.c);
		a1.display();
		a1.display1();

	}

}
