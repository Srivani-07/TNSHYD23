package com.day6;//default

 class MyClass1 {
	void display() {
		System.out.println("Hello World");
	}

}
