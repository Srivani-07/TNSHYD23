package com.day7;
import com.day6.*;

public class MyClass2 {
	public static void main(String[] args) {
		Myclass1 obj = new MyClass1();
		obj.display();
		
	}
	

}
