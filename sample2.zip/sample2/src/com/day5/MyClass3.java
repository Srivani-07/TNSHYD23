package com.day5;

 class MyClass3 {
	private void display() {
		System.out.println("TNS sessions");
	}
	public static void main(String[] args) {
		MyClass3 obj = new MyClass3();
		obj.display();
	}

}
