package com.day5;//private

 class MyClass1 {
	private void display(){
		System.out.println("TNS sessions");
	}

}
