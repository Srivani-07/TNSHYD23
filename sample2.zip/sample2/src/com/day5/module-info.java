
module sample2 {
}