package pack1;// public

public class A {
	public void display() {
		System.out.println("TNS sessions");
	}

}
