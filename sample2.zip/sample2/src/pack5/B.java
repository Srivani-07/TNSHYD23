package pack5;
import pack3.*;
import pack4.*;
 class B {
       public static void main(String[] args) {
		C obj = new C();
		D obj1 = new D();
		obj.msg();
		obj1.msg();
	}
}
