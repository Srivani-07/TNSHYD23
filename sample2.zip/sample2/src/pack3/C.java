package pack3;//packages

public class C {
	public void msg() {
		System.out.println("Hello C");
	}

}
