package pack4;//package

public class D {
         public void msg() {
        	 System.out.println("Hello D");
         }
}
